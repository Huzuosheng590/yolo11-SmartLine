import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO


if __name__ == '__main__':
    model = YOLO(r'runs\train\City\weights\best.pt')
    model.val(data=r'ultralytics\cfg\datasets\second-train.yaml',
              split='val',
              imgsz=640,
              batch=16,
              iou=0.6,
              conf=0.25,
              rect=True,
              save_json=False,
              project='runs/val',
              name='exp',
              )