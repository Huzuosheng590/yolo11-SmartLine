import albumentations as A
import cv2
import os


input_dir = r"G:\ultralytics-main\ultralytics-main\ultralytics\cfg\datasets\Ours\test\images"

output_dir = r"G:\ultralytics-main\ultralytics-main\ultralytics\cfg\datasets\Ours\test2\images"

os.makedirs(output_dir, exist_ok=True)


low_light = A.Compose([
    A.RandomBrightnessContrast(
        brightness_limit=(-0.4, -0.3),
        contrast_limit=(-0.2, 0),
        p=1.0
    )
])


for filename in os.listdir(input_dir):

    if filename.lower().endswith((".jpg",".png",".jpeg")):

        img_path = os.path.join(input_dir, filename)

        img = cv2.imread(img_path)

        if img is None:
            continue

        aug = low_light(image=img)["image"]

        save_path = os.path.join(output_dir, filename)

        cv2.imwrite(save_path, aug)

        print("完成:", filename)


print("低光数据生成完成")